using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class HighScores {
    public struct HighScore {
        public string nickName;
        public float score;
    }

    private static int _highScoresNumber = 3;
    public HighScore[] highScores = new HighScore[_highScoresNumber];

    public HighScores (string nickName, float score, int position) {
        for(int i = _highScoresNumber-1; i > position; i--) {
            highScores[i].nickName = highScores[i-1].nickName;
            highScores[i].score = highScores[i-1].score;
        }
        
        highScores[position].nickName = nickName;
        highScores[position].score = score;
    }
}
