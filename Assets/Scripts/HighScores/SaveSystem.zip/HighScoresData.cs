using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class HighScoresData {
    private static int _highScoresNumber = 3;
    public HighScores[] newHighScores = new HighScores[_highScoresNumber];

    public HighScoresData (HighScores highScores, string nickName, float score, int position) {
        for(int i = _highScoresNumber-1; i >= 0; i--) {
            if(i > position) {
                newHighScores[i].nickName = highScores[i-1].nickName;
                newHighScores[i].score = highScores[i-1].score;
            } else if(i == position) {
                newHighScores[i].nickName = nickName;
                newHighScores[i].score = score;
            } else {
                newHighScores[i].nickName = highScores[i].nickName;
                newHighScores[i].score = highScores[i].score;
            }
        }
    }
}
